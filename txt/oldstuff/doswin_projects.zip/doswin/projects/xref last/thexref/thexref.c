#define STRICT
#include <windows.h>
#include "thexref.h"

struct byte_U_type{
		  int defs:1;
		 int unpkd:1;
	     int declcache:1;
		int defscache:1;
	       int unpkdcache:1;
		 int atomcache:1;
		 int Usize:1;
		 int free:1;
} U_type;

void CALLBACK __export shit(void)
{
}

/* LibMain --------------------------------------------------------*
 *    Called by Windows when the library is loaded.  Registers the *
 *          Custom control class.                                           *                                          *
 * ----------------------------------------------------------------*/


#pragma argsused // wDataSeg, cbHeapSize, lpszCmdLine not used
int FAR PASCAL LibMain(HINSTANCE hInst, WORD wDataSeg, WORD cbHeapSize,
                        LPSTR lpszCmdLine)
{
	return 1;
}
