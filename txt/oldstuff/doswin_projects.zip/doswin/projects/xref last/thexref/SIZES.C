#include <stdio.h>

struct byte_U_type{
		  int defs:1;
		 int unpkd:1;
	     int declcache:1;
		int defscache:1;
	       int unpkdcache:1;
		 int atomcache:1;
		 int Usize:1;
		 int free:1;
} U_type;

class stars {
  int magnitude;
  int starfunc(void);
};



void main(void)
{
 printf("%d\n",sizeof(U_type));

}