/*class ujd {
public:
//                constructor ~universe;
//                destructor  ~universe;
};
*/